# راهنمای اجرای بازی محافظان پوست روی گیت‌هاب و هاست پایتون

> **نکته مهم درباره گیت‌هاب (GitHub Pages):**
> سرویس **GitHub Pages** فقط فایل‌های استاتیک (`HTML/CSS/JS`) را اجرا می‌کند و خودش کد پایتون را اجرا نمی‌کند. بنابراین:
> - خود بازی (همه برج‌ها، دشمن‌ها، باس امپراتور آکنه و بهینه‌سازی ضدلگ) **مستقیم با یک فایل `index.html` روی گیت‌هاب پیجز کامل اجرا می‌شود**.
> - برای اینکه **لیدربرد آنلاین SQLite** هم کار کند، کد پایتون را از همین مخزن گیت‌هاب به یک هاست پایتون رایگان (مثل **Render** یا **PythonAnywhere**) وصل می‌کنید و آدرسش را داخل `index.html` می‌گذارید.

---

## روش اول: کل مخزن روی گیت‌هاب (GitHub Pages + بک‌اند پایتون رایگان)

### ۱. ساخت مخزن روی گیت‌هاب و فعال‌سازی بازی (GitHub Pages)
1. یک مخزن جدید در گیت‌هاب بسازید (مثلاً `skin-defenders`).
2. همه فایل‌های داخل زیپ را در مخزن آپلود کنید:
   `app.py`، `leaderboard.py`، `game_data.py`، `passenger_wsgi.py`، `Procfile`، `requirements.txt` و پوشه `templates`.
3. فایل `templates/index.html` را در **روت مخزن** با نام `index.html` کپی کنید (یا بعد از ویرایش مرحله ۳ در روت مخزن بگذارید).
4. در مخزن گیت‌هاب به **Settings → Pages** بروید، در بخش **Build and deployment** گزینه **Deploy from a branch** و شاخه `main` / پوشه `/ (root)` را انتخاب و **Save** کنید.
   - لینک بازی شما روی گیت‌هاب آماده می‌شود: `https://USERNAME.github.io/skin-defenders/`

### ۲. اتصال رایگان همین مخزن گیت‌هاب به هاست پایتون (برای لیدربرد آنلاین)
دو راه ساده دارید (با وجود `Procfile` و `app.py` هیچ کتابخانه اضافی لازم نیست):

#### الف) روی Render.com (اتصال مستقیم به گیت‌هاب)
1. وارد [render.com](https://render.com) شوید و با اکانت گیت‌هاب لاگین کنید.
2. **New → Web Service** را بزنید و مخزن گیت‌هاب `skin-defenders` را انتخاب کنید.
3. تنظیمات:
   - **Runtime:** `Python 3`
   - **Start Command:** `python3 app.py`
4. دکمه **Create Web Service** را بزنید. یک لینک مثل `https://skin-defenders.onrender.com` به شما می‌دهد.

#### ب) روی PythonAnywhere.com
1. در تب **Consoles → Bash** مخزن گیت‌هاب را کلون کنید: `git clone https://github.com/USERNAME/skin-defenders.git`
2. در تب **Web → Add a new web app → Manual configuration → Python 3.10** بروید.
3. داخل **WSGI configuration file** این ۳ خط را بگذارید:
   ```python
   import sys
   sys.path.insert(0, '/home/USERNAME/skin-defenders')
   from app import application
   ```
4. **Reload** بزنید تا آدرس `https://USERNAME.pythonanywhere.com` فعال شود.

### ۳. وصل کردن `index.html` گیت‌هاب به سرور پایتون
1. فایل `index.html` (که در روت مخزن گیت‌هاب گذاشتید) را باز کنید و خط زیر را پیدا کنید:
   ```js
   const PYTHON_SERVER_URL='';
   ```
2. آدرس سرور پایتون مرحله ۲ را (بدون `/` در آخر) داخل آن بنویسید:
   ```js
   const PYTHON_SERVER_URL='https://skin-defenders.onrender.com';
   ```
3. تغییرات را Commit کنید؛ لیدربرد آنلاین روی GitHub Pages و سایت خودتان (بدون نیاز به کلادفلر) بلافاصله کار می‌کند.

---

## روش دوم: فقط تمپلت روی سایت خودتان + هاست اشتراکی (cPanel / DirectAdmin)
1. در **Setup Python App** نسخه `3.10+`، فایل شروع `passenger_wsgi.py` و Entry point را `application` قرار دهید.
2. فایل‌های پایتون را آپلود و **Restart** کنید.
3. در تمپلت `index.html` سایت خودتان، `PYTHON_SERVER_URL` را روی آدرس دامنه هاست پایتون قرار دهید.
